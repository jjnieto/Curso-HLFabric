/* gradient.js — gradient-descent animations: 2D loss curve + 3D wireframe bowl. */
(function () {
  const NS = "http://www.w3.org/2000/svg";
  const C = { primary: "#6022a2", fg: "#0a0a0a", mut: "#737373", border: "#e5e5e5",
    h2: "#fe9a00", soft: "#ece3f7" };
  function el(tag, attrs, text) {
    const n = document.createElementNS(NS, tag);
    for (const k in (attrs || {})) n.setAttribute(k, attrs[k]);
    if (text != null) n.textContent = text;
    return n;
  }

  /* ── 2D loss curve with a descending ball ──────────────────────── */
  function makeLossCurve(svg, onStep) {
    const W = 720, H = 560;
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
    svg.setAttribute("class", "diag");
    const L = 78, R = W - 36, T = 56, B = H - 78;

    const loss = (x) => 0.55 * (x - 6.8) ** 2 + 1.6;     // x in [0,10]
    const grad = (x) => 1.1 * (x - 6.8);
    const xmin = 0, xmax = 10, ymin = 0, ymax = loss(0) + 1;
    const sx = (x) => L + ((x - xmin) / (xmax - xmin)) * (R - L);
    const sy = (y) => B - ((y - ymin) / (ymax - ymin)) * (B - T);

    let timer = null;
    function frame() {
      svg.innerHTML = "";
      // axes
      svg.appendChild(el("line", { x1: L, y1: B, x2: R, y2: B, stroke: C.border, "stroke-width": 2 }));
      svg.appendChild(el("line", { x1: L, y1: T, x2: L, y2: B, stroke: C.border, "stroke-width": 2 }));
      svg.appendChild(el("text", { x: (L + R) / 2, y: H - 30, fill: C.mut, "font-size": 22, "text-anchor": "middle" }, "valor de un peso"));
      const yl = el("text", { x: 30, y: (T + B) / 2, fill: C.mut, "font-size": 22, "text-anchor": "middle",
        transform: `rotate(-90 30 ${(T + B) / 2})` }, "error");
      svg.appendChild(yl);
      // curve
      let d = "";
      for (let i = 0; i <= 120; i++) {
        const x = xmin + ((xmax - xmin) * i) / 120;
        d += (i === 0 ? "M" : "L") + sx(x) + "," + sy(loss(x));
      }
      svg.appendChild(el("path", { d, fill: "none", stroke: C.border, "stroke-width": 4 }));
      // minimum marker
      svg.appendChild(el("circle", { cx: sx(6.8), cy: sy(loss(6.8)), r: 6, fill: "#2f9f3d" }));
      svg.appendChild(el("text", { x: sx(6.8), y: sy(loss(6.8)) + 34, fill: "#1c5c23", "font-size": 19, "text-anchor": "middle" }, "mínimo"));
      return { sx, sy };
    }

    function render(state) {
      const { sx, sy } = frame();
      // trail
      state.trail.forEach((tx, i) => {
        svg.appendChild(el("circle", { cx: sx(tx), cy: sy(loss(tx)), r: 5,
          fill: C.primary, "fill-opacity": 0.18 + 0.5 * (i / state.trail.length) }));
      });
      // tangent (slope) segment at current x
      const x = state.x, g = grad(x);
      const dx = 1.1;
      const x1 = x - dx, x2 = x + dx;
      const ix1 = sx(x1), iy1 = sy(loss(x) - g * dx);
      const ix2 = sx(x2), iy2 = sy(loss(x) + g * dx);
      svg.appendChild(el("line", { x1: ix1, y1: iy1, x2: ix2, y2: iy2,
        stroke: C.h2, "stroke-width": 4, "stroke-linecap": "round", "stroke-dasharray": "2 8" }));
      svg.appendChild(el("text", { x: ix2 + 6, y: iy2, fill: C.h2, "font-size": 18, "font-weight": 600 }, "pendiente"));
      // ball
      svg.appendChild(el("circle", { cx: sx(x), cy: sy(loss(x)), r: 15, fill: C.primary, stroke: "#fff", "stroke-width": 3 }));
      if (onStep) onStep(state.step, loss(x));
    }

    function play() {
      if (timer) clearInterval(timer);
      const state = { x: 1.0, step: 0, trail: [] };
      render(state);
      timer = setInterval(() => {
        state.trail.push(state.x);
        state.x -= 0.11 * grad(state.x);
        state.step++;
        render(state);
        if (state.step >= 16 || Math.abs(grad(state.x)) < 0.05) clearInterval(timer);
      }, 480);
    }
    frame();
    // resting state: ball at start
    render({ x: 1.0, step: 0, trail: [] });
    return { play };
  }

  /* ── 3D wireframe bowl with a descending ball ──────────────────── */
  function makeSurface(svg, onStep) {
    const W = 720, H = 560;
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
    svg.setAttribute("class", "diag");
    const cx = 360, cy = 388, sX = 188, sY = 96, hScale = 150;
    const zf = (u, v) => (u * u + v * v);           // bowl
    const proj = (u, v) => {
      const z = zf(u, v);
      return { x: cx + (u - v) * sX, y: cy + (u + v) * sY - z * hScale };
    };
    const N = 12;
    const lin = (i) => -1 + (2 * i) / N;

    let timer = null;
    function frame() {
      svg.innerHTML = "";
      // mesh lines along u and v
      for (let i = 0; i <= N; i++) {
        let du = "", dv = "";
        for (let j = 0; j <= N; j++) {
          const a = proj(lin(i), lin(j));
          const b = proj(lin(j), lin(i));
          du += (j === 0 ? "M" : "L") + a.x + "," + a.y;
          dv += (j === 0 ? "M" : "L") + b.x + "," + b.y;
        }
        const edge = (i === 0 || i === N);
        svg.appendChild(el("path", { d: du, fill: "none", stroke: edge ? "#c9b9e0" : C.border,
          "stroke-width": edge ? 2 : 1.4, "stroke-opacity": edge ? 1 : 0.8 }));
        svg.appendChild(el("path", { d: dv, fill: "none", stroke: edge ? "#c9b9e0" : C.border,
          "stroke-width": edge ? 2 : 1.4, "stroke-opacity": edge ? 1 : 0.8 }));
      }
      // minimum marker at center
      const m = proj(0, 0);
      svg.appendChild(el("circle", { cx: m.x, cy: m.y, r: 6, fill: "#2f9f3d" }));
      svg.appendChild(el("text", { x: m.x, y: m.y + 30, fill: "#1c5c23", "font-size": 18, "text-anchor": "middle" }, "mínimo"));
    }

    function render(state) {
      frame();
      // trail
      for (let i = 1; i < state.trail.length; i++) {
        const a = proj(state.trail[i - 1].u, state.trail[i - 1].v);
        const b = proj(state.trail[i].u, state.trail[i].v);
        svg.appendChild(el("line", { x1: a.x, y1: a.y, x2: b.x, y2: b.y,
          stroke: C.primary, "stroke-width": 4, "stroke-opacity": 0.55, "stroke-linecap": "round" }));
      }
      const p = proj(state.u, state.v);
      svg.appendChild(el("circle", { cx: p.x, cy: p.y, r: 14, fill: C.primary, stroke: "#fff", "stroke-width": 3 }));
      if (onStep) onStep(state.step, zf(state.u, state.v));
    }

    function play() {
      if (timer) clearInterval(timer);
      const state = { u: -0.92, v: 0.74, step: 0, trail: [{ u: -0.92, v: 0.74 }] };
      render(state);
      timer = setInterval(() => {
        state.u -= 0.16 * (2 * state.u);
        state.v -= 0.16 * (2 * state.v);
        state.step++;
        state.trail.push({ u: state.u, v: state.v });
        render(state);
        if (state.step >= 18 || (Math.abs(state.u) < 0.02 && Math.abs(state.v) < 0.02)) clearInterval(timer);
      }, 460);
    }
    frame();
    render({ u: -0.92, v: 0.74, step: 0, trail: [{ u: -0.92, v: 0.74 }] });
    return { play };
  }

  window.NNGradient = { makeLossCurve, makeSurface };
})();
