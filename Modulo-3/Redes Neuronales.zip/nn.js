/* nn.js — draws an SVG feed-forward network and animates a forward pass.
   Vanilla JS. Used by the structure slide and the animated forward-pass slide. */
(function () {
  const NS = "http://www.w3.org/2000/svg";
  const COLORS = {
    input:  { c: "#6022a2", soft: "#ece3f7" },
    h1:     { c: "#007867", soft: "#d8ece8" },
    h2:     { c: "#fe9a00", soft: "#ffeccd" },
    output: { c: "#d7427e", soft: "#fadbe7" },
  };

  function el(tag, attrs) {
    const n = document.createElementNS(NS, tag);
    for (const k in attrs) n.setAttribute(k, attrs[k]);
    return n;
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // opts.layers: [{ count, key, label }]
  function buildNetwork(svg, opts) {
    const W = 1000, H = 620;
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
    svg.setAttribute("class", "net");
    svg.innerHTML = "";

    const L = opts.layers;
    const padX = 110, padTop = 70, padBot = 70;
    const innerW = W - padX * 2;
    const r = 30;

    // positions
    const layers = L.map((cfg, i) => {
      const x = L.length === 1 ? W / 2 : padX + (innerW * i) / (L.length - 1);
      const n = cfg.count;
      const usableH = H - padTop - padBot;
      const gap = usableH / Math.max(n, 1);
      const neurons = [];
      for (let j = 0; j < n; j++) {
        const cy = padTop + gap * (j + 0.5);
        neurons.push({ cx: x, cy });
      }
      return { x, cfg, neurons, color: COLORS[cfg.key] };
    });

    // edges first (under neurons)
    const gEdges = el("g", {});
    svg.appendChild(gEdges);
    const edges = [];
    for (let i = 0; i < layers.length - 1; i++) {
      const a = layers[i], b = layers[i + 1];
      a.neurons.forEach((na, ai) => {
        b.neurons.forEach((nb, bi) => {
          const line = el("line", {
            x1: na.cx, y1: na.cy, x2: nb.cx, y2: nb.cy,
            class: "edge", "stroke-opacity": "0.55",
          });
          gEdges.appendChild(line);
          edges.push({ line, from: [i, ai], to: [i + 1, bi], color: b.color.c });
        });
      });
    }

    // pulse layer (above edges, below neurons)
    const gPulse = el("g", { class: "pulse" });
    svg.appendChild(gPulse);

    // neurons
    const gNodes = el("g", {});
    svg.appendChild(gNodes);
    layers.forEach((layer, li) => {
      layer.neurons.forEach((nu, ni) => {
        const g = el("g", { class: "neuron" });
        const ring = el("circle", {
          cx: nu.cx, cy: nu.cy, r, class: "neuron-ring",
          stroke: layer.color.c,
        });
        const text = el("text", {
          x: nu.cx, y: nu.cy, class: "neuron-val", "font-size": "26",
        });
        g.appendChild(ring);
        g.appendChild(text);
        gNodes.appendChild(g);
        nu.g = g; nu.ring = ring; nu.text = text; nu.color = layer.color;
      });

      // column labels
      if (opts.labels !== false) {
        const lblY = 34;
        const lbl = el("text", {
          x: layer.x, y: lblY, class: "col-label",
          "font-size": "26", "font-weight": "600", fill: layer.color.c,
        });
        lbl.textContent = layer.cfg.label;
        svg.appendChild(lbl);
        const cnt = el("text", {
          x: layer.x, y: H - 24, class: "col-count", "font-size": "24",
        });
        cnt.textContent = layer.cfg.count + (layer.cfg.count === 1 ? " neurona" : " neuronas");
        svg.appendChild(cnt);
      }
    });

    function reset() {
      gPulse.innerHTML = "";
      edges.forEach((e) => {
        e.line.classList.remove("hot");
        e.line.setAttribute("stroke", "var(--border)");
        e.line.setAttribute("stroke-opacity", "0.5");
        e.line.setAttribute("stroke-width", "2");
      });
      layers.forEach((layer) =>
        layer.neurons.forEach((nu) => {
          nu.g.classList.remove("lit");
          nu.ring.setAttribute("fill", "#ffffff");
          nu.text.textContent = "";
        })
      );
    }

    function litNeuron(li, ni, value) {
      const nu = layers[li].neurons[ni];
      nu.g.classList.add("lit");
      nu.ring.setAttribute("fill", nu.color.soft);
      nu.text.setAttribute("fill", nu.color.c);
      nu.text.textContent = value;
    }

    // fire pulses along all edges from layer li-1 into layer li, then light layer
    async function activateLayer(li, values, opts2 = {}) {
      const dur = opts2.dur || 620;
      const incoming = edges.filter((e) => e.to[0] === li);
      // heat edges
      incoming.forEach((e) => {
        e.line.classList.add("hot");
        e.line.setAttribute("stroke", e.color);
        e.line.setAttribute("stroke-opacity", "0.9");
        e.line.setAttribute("stroke-width", "3");
      });
      // launch pulses
      incoming.forEach((e) => {
        const a = layers[e.from[0]].neurons[e.from[1]];
        const b = layers[e.to[0]].neurons[e.to[1]];
        const dot = el("circle", { cx: a.cx, cy: a.cy, r: 6, fill: e.color });
        gPulse.appendChild(dot);
        const anim = dot.animate(
          [
            { transform: "translate(0,0)", opacity: 0.2 },
            { opacity: 1, offset: 0.15 },
            { transform: `translate(${b.cx - a.cx}px, ${b.cy - a.cy}px)`, opacity: 0.9 },
          ],
          { duration: dur, easing: "cubic-bezier(.4,0,.2,1)", fill: "forwards" }
        );
        anim.onfinish = () => dot.remove();
      });
      await sleep(dur * 0.78);
      // light up target neurons
      layers[li].neurons.forEach((nu, ni) => litNeuron(li, ni, values[ni]));
      await sleep(220);
      // cool edges back to a tinted-but-quiet state
      incoming.forEach((e) => {
        e.line.setAttribute("stroke-opacity", "0.35");
        e.line.setAttribute("stroke-width", "2.5");
      });
    }

    // valuesByLayer: array (one per layer) of arrays of display strings
    async function play(valuesByLayer, opts2 = {}) {
      reset();
      await sleep(150);
      // input layer lights immediately
      layers[0].neurons.forEach((nu, ni) => litNeuron(0, ni, valuesByLayer[0][ni]));
      await sleep(560);
      for (let li = 1; li < layers.length; li++) {
        await activateLayer(li, valuesByLayer[li], opts2);
        await sleep(160);
      }
    }

    function showStatic(valuesByLayer) {
      reset();
      layers.forEach((layer, li) => {
        if (!valuesByLayer || !valuesByLayer[li]) return;
        layer.neurons.forEach((nu, ni) => litNeuron(li, ni, valuesByLayer[li][ni]));
      });
    }

    return { svg, layers, edges, reset, play, showStatic, litNeuron, activateLayer };
  }

  window.buildNetwork = buildNetwork;
  window.NN_COLORS = COLORS;
})();
