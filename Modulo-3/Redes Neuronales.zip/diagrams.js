/* diagrams.js — bespoke SVG diagrams: single neuron, activation curves,
   MNIST digit + flatten strip + schematic net + output bars, training loop. */
(function () {
  const NS = "http://www.w3.org/2000/svg";
  const C = {
    input: "#6022a2", inputSoft: "#ece3f7",
    h1: "#007867", h2: "#fe9a00",
    output: "#d7427e", outputSoft: "#fadbe7",
    fg: "#0a0a0a", mut: "#737373", border: "#e5e5e5", muted: "#f3f3f3",
  };
  function el(tag, attrs, text) {
    const n = document.createElementNS(NS, tag);
    for (const k in (attrs || {})) n.setAttribute(k, attrs[k]);
    if (text != null) n.textContent = text;
    return n;
  }
  function defsArrow(svg, id, color) {
    const defs = el("defs");
    const m = el("marker", { id, viewBox: "0 0 10 10", refX: "8", refY: "5",
      markerWidth: "7", markerHeight: "7", orient: "auto-start-reverse" });
    m.appendChild(el("path", { d: "M0,0 L10,5 L0,10 z", fill: color }));
    defs.appendChild(m); svg.appendChild(defs);
  }

  /* ── Single neuron ─────────────────────────────────────────────── */
  function drawNeuron(svg) {
    svg.setAttribute("viewBox", "0 0 820 560");
    svg.setAttribute("class", "diag");
    svg.innerHTML = "";
    defsArrow(svg, "arrN", C.mut);

    const inputs = [
      { y: 130, lbl: "x₁" }, { y: 280, lbl: "x₂" }, { y: 430, lbl: "x₃" },
    ];
    const sum = { x: 410, y: 280 };
    // weight lines
    inputs.forEach((p, i) => {
      svg.appendChild(el("line", { x1: 110, y1: p.y, x2: sum.x - 56, y2: sum.y,
        stroke: C.h1, "stroke-width": 3, "stroke-opacity": .75 }));
      // weight label near input
      const mx = 110 + (sum.x - 56 - 110) * 0.32;
      const my = p.y + (sum.y - p.y) * 0.32 - 12;
      svg.appendChild(el("text", { x: mx, y: my, fill: C.h1, "font-size": 24,
        "font-weight": 700, "text-anchor": "middle", "font-family": "var(--font-mono)" }, "w" + (i + 1)));
    });
    // bias line
    svg.appendChild(el("line", { x1: 250, y1: 500, x2: sum.x - 30, y2: sum.y + 44,
      stroke: C.h2, "stroke-width": 3, "stroke-opacity": .75 }));

    // input nodes
    inputs.forEach((p) => {
      svg.appendChild(el("circle", { cx: 80, cy: p.y, r: 36, fill: C.inputSoft, stroke: C.input, "stroke-width": 4 }));
      svg.appendChild(el("text", { x: 80, y: p.y, fill: C.input, "font-size": 28, "font-weight": 700,
        "text-anchor": "middle", "dominant-baseline": "central", "font-family": "var(--font-mono)" }, p.lbl));
    });
    // bias node
    svg.appendChild(el("circle", { cx: 250, cy: 500, r: 28, fill: "#ffeccd", stroke: C.h2, "stroke-width": 4 }));
    svg.appendChild(el("text", { x: 250, y: 500, fill: C.h2, "font-size": 26, "font-weight": 700,
      "text-anchor": "middle", "dominant-baseline": "central", "font-family": "var(--font-mono)" }, "b"));
    svg.appendChild(el("text", { x: 250, y: 548, fill: C.mut, "font-size": 19, "text-anchor": "middle" }, "sesgo"));

    // sum node
    svg.appendChild(el("circle", { cx: sum.x, cy: sum.y, r: 56, fill: "#fff", stroke: C.fg, "stroke-width": 4 }));
    svg.appendChild(el("text", { x: sum.x, y: sum.y, fill: C.fg, "font-size": 56, "font-weight": 600,
      "text-anchor": "middle", "dominant-baseline": "central" }, "Σ"));
    svg.appendChild(el("text", { x: sum.x, y: sum.y + 92, fill: C.mut, "font-size": 19, "text-anchor": "middle" }, "suma ponderada"));

    // sum -> activation
    svg.appendChild(el("line", { x1: sum.x + 56, y1: sum.y, x2: 558, y2: sum.y,
      stroke: C.mut, "stroke-width": 3, "marker-end": "url(#arrN)" }));
    // activation box
    svg.appendChild(el("rect", { x: 560, y: 222, width: 120, height: 116, rx: 16,
      fill: "#fff", stroke: C.output, "stroke-width": 4 }));
    svg.appendChild(el("text", { x: 620, y: 270, fill: C.output, "font-size": 44, "font-weight": 700,
      "text-anchor": "middle", "font-family": "var(--font-mono)" }, "f"));
    svg.appendChild(el("text", { x: 620, y: 312, fill: C.mut, "font-size": 18, "text-anchor": "middle" }, "activación"));
    // activation -> output
    svg.appendChild(el("line", { x1: 680, y1: sum.y, x2: 742, y2: sum.y,
      stroke: C.mut, "stroke-width": 3, "marker-end": "url(#arrN)" }));
    svg.appendChild(el("circle", { cx: 786, cy: sum.y, r: 32, fill: C.outputSoft, stroke: C.output, "stroke-width": 4 }));
    svg.appendChild(el("text", { x: 786, y: sum.y, fill: C.output, "font-size": 26, "font-weight": 700,
      "text-anchor": "middle", "dominant-baseline": "central", "font-family": "var(--font-mono)" }, "a"));
    svg.appendChild(el("text", { x: 786, y: sum.y + 58, fill: C.mut, "font-size": 19, "text-anchor": "middle" }, "salida"));
  }

  /* ── Activation curve ──────────────────────────────────────────── */
  function drawActivation(svg, kind) {
    const W = 460, H = 360;
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
    svg.setAttribute("preserveAspectRatio", "xMidYMid meet");
    svg.innerHTML = "";
    const L = 64, R = W - 30, T = 36, B = H - 40; // plot box
    const isRelu = kind === "relu";
    const color = isRelu ? C.h2 : C.h1;
    const xmin = -6, xmax = 6;
    const ymin = isRelu ? 0 : 0, ymax = isRelu ? 6 : 1;
    const sx = (x) => L + ((x - xmin) / (xmax - xmin)) * (R - L);
    const sy = (y) => B - ((y - ymin) / (ymax - ymin)) * (B - T);

    // axes
    const y0 = sy(0), x0 = sx(0);
    svg.appendChild(el("line", { x1: L, y1: y0, x2: R, y2: y0, stroke: C.border, "stroke-width": 2 }));
    svg.appendChild(el("line", { x1: x0, y1: T - 6, x2: x0, y2: B + 6, stroke: C.border, "stroke-width": 2 }));

    // curve
    let d = "";
    for (let i = 0; i <= 120; i++) {
      const x = xmin + ((xmax - xmin) * i) / 120;
      let y = isRelu ? Math.max(0, x) : 1 / (1 + Math.exp(-x));
      d += (i === 0 ? "M" : "L") + sx(x) + "," + sy(y);
    }
    svg.appendChild(el("path", { d, fill: "none", stroke: color, "stroke-width": 6,
      "stroke-linecap": "round", "stroke-linejoin": "round" }));
  }

  /* ── MNIST: digit grid + flatten strip (via offscreen canvas) ──── */
  function drawDigit(gridEl, stripEl, digit) {
    const N = 28;
    const cv = document.createElement("canvas");
    cv.width = N; cv.height = N;
    const ctx = cv.getContext("2d");
    ctx.fillStyle = "#000"; ctx.fillRect(0, 0, N, N);
    ctx.fillStyle = "#fff";
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.font = "bold 24px Georgia, 'Times New Roman', serif";
    // slight slant to feel hand-written
    ctx.save();
    ctx.translate(N / 2, N / 2 + 1);
    ctx.transform(1, 0, -0.12, 1, 0, 0);
    ctx.fillText(String(digit), 0, 0);
    ctx.restore();
    const data = ctx.getImageData(0, 0, N, N).data;

    gridEl.innerHTML = "";
    const vals = [];
    for (let i = 0; i < N * N; i++) {
      const v = data[i * 4]; // brightness (white digit on black)
      vals.push(v / 255);
      const cell = document.createElement("div");
      cell.style.background = `rgb(${v},${v},${v})`;
      gridEl.appendChild(cell);
    }
    // flatten strip: sample 16 representative buckets
    if (stripEl) {
      stripEl.innerHTML = "";
      const rows = 16;
      for (let r = 0; r < rows; r++) {
        const start = Math.floor((r / rows) * vals.length);
        const end = Math.floor(((r + 1) / rows) * vals.length);
        let m = 0; for (let k = start; k < end; k++) m = Math.max(m, vals[k]);
        const v = Math.round(m * 255);
        const cell = document.createElement("div");
        cell.style.background = `rgb(${v},${v},${v})`;
        stripEl.appendChild(cell);
      }
    }
  }

  /* ── MNIST schematic net (with ellipsis) ──────────────────────── */
  function drawMnistNet(svg) {
    const W = 460, H = 300;
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
    svg.setAttribute("class", "diag");
    svg.innerHTML = "";
    const cols = [
      { x: 60, n: 6, color: C.input },
      { x: 200, n: 5, color: C.h1 },
      { x: 340, n: 6, color: C.h2 },
    ];
    const top = 46, bot = H - 46, r = 9;
    const pos = cols.map((c) => {
      const gap = (bot - top) / (c.n - 1);
      return { x: c.x, color: c.color, ys: Array.from({ length: c.n }, (_, j) => top + gap * j) };
    });
    // edges
    for (let i = 0; i < pos.length - 1; i++) {
      pos[i].ys.forEach((y1) => pos[i + 1].ys.forEach((y2) => {
        svg.appendChild(el("line", { x1: pos[i].x, y1, x2: pos[i + 1].x, y2,
          stroke: C.border, "stroke-width": 1, "stroke-opacity": .5 }));
      }));
    }
    pos.forEach((c) => {
      c.ys.forEach((y) => svg.appendChild(el("circle", { cx: c.x, cy: y, r, fill: "#fff", stroke: c.color, "stroke-width": 3 })));
      svg.appendChild(el("text", { x: c.x, y: H - 14, fill: C.mut, "font-size": 16, "text-anchor": "middle" }, "⋮"));
    });
  }

  function drawMnistOutput(container, digit) {
    // plausible softmax-like distribution favouring `digit`
    const base = [0.02, 0.01, 0.03, 0.0, 0.04, 0.02, 0.01, 0.05, 0.03, 0.02];
    base[digit] = 0.0;
    const win = 0.92;
    container.innerHTML = "";
    for (let d = 0; d <= 9; d++) {
      const p = d === digit ? win : base[d];
      const row = document.createElement("div");
      row.className = "obar" + (d === digit ? " win" : "");
      row.innerHTML = `<div class="d">${d}</div><div class="track"><div class="fill" style="width:0"></div></div><div class="pct">${Math.round(p * 100)}%</div>`;
      container.appendChild(row);
      const fill = row.querySelector(".fill");
      fill.style.transition = "width .8s cubic-bezier(.4,0,.2,1)";
      fill.style.width = "0";
      setTimeout(() => { fill.style.width = (p * 100) + "%"; }, 60);
    }
  }

  /* ── Training loop ─────────────────────────────────────────────── */
  function drawTrainLoop(svg) {
    const W = 1180, H = 600;
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
    svg.setAttribute("class", "diag");
    svg.innerHTML = "";
    defsArrow(svg, "arrLoop", C.input);
    const cx = W / 2, cy = H / 2 + 6, R = 210;
    const nodes = [
      { a: -90, t: "Predecir", s: "con los pesos actuales", icon: C.input },
      { a: 30, t: "Medir el error", s: "predicción vs. respuesta correcta", icon: C.h1 },
      { a: 150, t: "Ajustar los pesos", s: "retropropagación + gradiente", icon: C.output },
    ];
    const bw = 320, bh = 116;
    const pts = nodes.map((n) => {
      const rad = (n.a * Math.PI) / 180;
      return { x: cx + R * Math.cos(rad) * 1.25, y: cy + R * Math.sin(rad), ...n };
    });
    // arrows between consecutive nodes (curved through center-ish)
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i], b = pts[(i + 1) % pts.length];
      const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
      // pull control point toward center to bow the arc
      const ctrlx = mx + (cx - mx) * -0.45;
      const ctrly = my + (cy - my) * -0.45;
      // trim endpoints toward node centers
      const trim = (p, q) => {
        const dx = q.x - p.x, dy = q.y - p.y, len = Math.hypot(dx, dy);
        return { x: p.x + (dx / len) * 120, y: p.y + (dy / len) * 70 };
      };
      const s = trim(a, { x: ctrlx, y: ctrly });
      const e = trim(b, { x: ctrlx, y: ctrly });
      svg.appendChild(el("path", { d: `M${s.x},${s.y} Q${ctrlx},${ctrly} ${e.x},${e.y}`,
        fill: "none", stroke: C.input, "stroke-width": 3.5, "stroke-opacity": .8, "marker-end": "url(#arrLoop)" }));
    }
    // center label
    svg.appendChild(el("text", { x: cx, y: cy - 44, fill: C.fg, "font-size": 30, "font-weight": 600, "text-anchor": "middle" }, "Repetir"));
    svg.appendChild(el("text", { x: cx, y: cy - 8, fill: C.mut, "font-size": 21, "text-anchor": "middle" }, "una época = una vuelta"));
    svg.appendChild(el("text", { x: cx, y: cy + 18, fill: C.mut, "font-size": 21, "text-anchor": "middle" }, "con todos los ejemplos"));
    // node boxes
    pts.forEach((p, i) => {
      const x = p.x - bw / 2, y = p.y - bh / 2;
      svg.appendChild(el("rect", { x, y, width: bw, height: bh, rx: 18, fill: "#fff", stroke: p.icon, "stroke-width": 3 }));
      svg.appendChild(el("circle", { cx: x + 46, cy: p.y, r: 22, fill: p.icon }));
      svg.appendChild(el("text", { x: x + 46, y: p.y + 1, fill: "#fff", "font-size": 24, "font-weight": 700,
        "text-anchor": "middle", "dominant-baseline": "central" }, String(i + 1)));
      svg.appendChild(el("text", { x: x + 84, y: p.y - 12, fill: C.fg, "font-size": 27, "font-weight": 600 }, p.t));
      svg.appendChild(el("text", { x: x + 84, y: p.y + 22, fill: C.mut, "font-size": 19 }, p.s));
    });
  }

  window.NNDiagrams = { drawNeuron, drawActivation, drawDigit, drawMnistNet, drawMnistOutput, drawTrainLoop };
})();
