/* controller.js — builds all diagrams and triggers animations on slide change. */
(function () {
  const FWD_LAYERS = [
    { count: 3, key: "input", label: "Entrada" },
    { count: 4, key: "h1", label: "Oculta 1" },
    { count: 5, key: "h2", label: "Oculta 2" },
    { count: 3, key: "output", label: "Salida" },
  ];
  const FWD_VALUES = [
    ["0.7", "0.2", "0.9"],
    ["0.6", "0.1", "0.8", "0.3"],
    ["0.4", "0.8", "0.1", "0.6", "0.9"],
    ["0.82", "0.12", "0.06"],
  ];

  let fwdNet = null, lossCurve = null, surface = null, fwdTimer = null;

  function $(id) { return document.getElementById(id); }

  function buildAll() {
    // structure (static architecture, no values)
    const structSvg = $("netStructure");
    if (structSvg) buildNetwork(structSvg, { layers: FWD_LAYERS });

    // forward (animated)
    const fwdSvg = $("netForward");
    if (fwdSvg) fwdNet = buildNetwork(fwdSvg, { layers: FWD_LAYERS });

    // single neuron + activations
    if ($("neuronDiagram")) NNDiagrams.drawNeuron($("neuronDiagram"));
    if ($("actRelu")) NNDiagrams.drawActivation($("actRelu"), "relu");
    if ($("actSig")) NNDiagrams.drawActivation($("actSig"), "sigmoid");

    // mnist
    if ($("digitGrid")) NNDiagrams.drawDigit($("digitGrid"), $("flatStrip"), 3);
    if ($("mnistNet")) NNDiagrams.drawMnistNet($("mnistNet"));
    if ($("mnistOut")) NNDiagrams.drawMnistOutput($("mnistOut"), 3);

    // train loop
    if ($("trainLoop")) NNDiagrams.drawTrainLoop($("trainLoop"));

    // gradient instances
    if ($("lossCurve")) {
      lossCurve = NNGradient.makeLossCurve($("lossCurve"), (step, val) => {
        const s = $("lossStep"), v = $("lossVal");
        if (s) s.textContent = "Paso " + step;
        if (v) v.textContent = val.toFixed(2);
      });
    }
    if ($("lossSurface")) surface = NNGradient.makeSurface($("lossSurface"));
  }

  // ── forward-pass step highlighting synced to the animation ──────
  function highlightStep(i) {
    document.querySelectorAll('.step[data-step]').forEach((el) => {
      el.classList.toggle("on", Number(el.getAttribute("data-step")) === i);
    });
  }
  async function runForward() {
    if (!fwdNet) return;
    const steps = document.querySelectorAll('.step[data-step]');
    steps.forEach((el) => el.classList.remove("on"));
    if (fwdTimer) fwdTimer.forEach(clearTimeout);
    fwdTimer = [];
    // schedule step highlights roughly in sync with nn.play timings
    const times = [200, 900, 1850, 2900];
    times.forEach((t, i) => fwdTimer.push(setTimeout(() => highlightStep(i), t)));
    await fwdNet.play(FWD_VALUES);
    highlightStep(3);
  }

  // ── decision bars ───────────────────────────────────────────────
  function animateDecision(reset) {
    document.querySelectorAll('.probs .fill').forEach((f) => {
      f.style.width = reset ? "0" : (f.getAttribute("data-w") + "%");
    });
    document.querySelectorAll('.probs .pct').forEach((p) => {
      const target = Number(p.getAttribute("data-target"));
      if (p._cu) clearInterval(p._cu);
      if (reset) { p.textContent = "0 %"; return; }
      const t0 = performance.now(), dur = 900;
      p._cu = setInterval(() => {
        const k = Math.min(1, (performance.now() - t0) / dur);
        const e = 1 - Math.pow(1 - k, 3);
        p.textContent = Math.round(target * e) + " %";
        if (k >= 1) { clearInterval(p._cu); p._cu = null; }
      }, 32);
    });
  }

  // ── slide change routing ────────────────────────────────────────
  function onSlide(label) {
    if (label === "Forward pass") {
      runForward();
    }
    if (label === "Decisión") {
      animateDecision(true);
      setTimeout(() => animateDecision(false), 250);
    }
    if (label === "Gradiente · valle" && lossCurve) {
      setTimeout(() => lossCurve.play(), 250);
    }
    if (label === "Gradiente · superficie" && surface) {
      setTimeout(() => surface.play(), 250);
    }
  }

  document.addEventListener("slidechange", (e) => {
    const slide = e.detail && e.detail.slide;
    if (!slide) return;
    onSlide(slide.getAttribute("data-label"));
  });

  // replay buttons
  function wireButtons() {
    const rf = $("replayForward"); if (rf) rf.addEventListener("click", runForward);
    const rc = $("replayCurve"); if (rc) rc.addEventListener("click", () => lossCurve && lossCurve.play());
    const rs = $("replaySurface"); if (rs) rs.addEventListener("click", () => surface && surface.play());
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => { buildAll(); wireButtons(); });
  } else {
    buildAll(); wireButtons();
  }
})();
